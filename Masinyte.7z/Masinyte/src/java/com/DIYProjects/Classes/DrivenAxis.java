package com.DIYProjects.Classes;

public enum DrivenAxis {
    FRONT,
    REAR,
    ALL
}
